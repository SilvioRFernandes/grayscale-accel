

/***************************** Include Files *******************************/
#include "GrayScale_Accel_pipe.h"

/************************** Function Definitions ***************************/
